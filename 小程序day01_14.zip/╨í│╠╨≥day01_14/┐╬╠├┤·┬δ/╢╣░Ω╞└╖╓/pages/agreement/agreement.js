// pages/agreement/agreement.js
Page({
  
})