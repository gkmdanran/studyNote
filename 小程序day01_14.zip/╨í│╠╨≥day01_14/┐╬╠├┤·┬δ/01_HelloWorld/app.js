//app.js
App({
  onLaunch: function () {
    let a = 10;
    let b = 20;
    let c = a + b;
  }
})